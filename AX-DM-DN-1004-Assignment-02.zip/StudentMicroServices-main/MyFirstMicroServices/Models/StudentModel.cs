﻿
namespace MyFirstMicroServices.Models
{
    public class StudentModel
    {
        public int Id { get; set; }
        public string SName { get; set; }
        public string Course { get; set; }
        public int Fee { get; set; }
    }
}