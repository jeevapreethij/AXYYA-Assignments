﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidPriciplesPractice
{
    public enum CarModels
    {
        Maruthi = 0,
        Tata = 1,
        Mahindra = 2
    }
}
